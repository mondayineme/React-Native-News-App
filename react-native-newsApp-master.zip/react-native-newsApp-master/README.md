# React Native News App

This is a react native project created for tutorial purpose by **Pradip Debnath** for his [YouTube channel](https://www.youtube.com/user/itzpradip).

I have used NewsAPI.Org to fetch the news and NativeBase.io to build the UI of the app. You can [check full tutorial series here](https://www.youtube.com/playlist?list=PLQWFhX-gwJbl5sIXMZvdvGYCcZbUevE88).

##Screenshot
![News App User Interface](https://www.pradipdebnath.com/wp-content/uploads/2019/08/rn-newsApp-ui.png)