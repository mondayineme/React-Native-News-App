export const articles_url = 'https://newsapi.org/v2/top-headlines';
export const country_code = 'in';
export const category = 'general';
export const _api_key = '9cb9d883e8004f08a8e18daf96a0039c';